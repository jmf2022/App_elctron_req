export function Create(){
  return (
    <div>
      <h1>Página Novo cliente!!!</h1>
    </div>
  )
}