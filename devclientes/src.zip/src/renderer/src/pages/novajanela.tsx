import { Link } from 'react-router-dom'

export function Novajanela(){
  return (
    <div>
      
      <h3>Nova janela</h3>
      <Link to="/novajanela">Ir para Nova janela</Link>
    </div>
  )
}